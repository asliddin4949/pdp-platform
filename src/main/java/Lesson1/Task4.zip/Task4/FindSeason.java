package Lesson1.Task4;

public interface FindSeason {
    Season findSeason();
}
