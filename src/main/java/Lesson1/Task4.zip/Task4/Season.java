package Lesson1.Task4;

public enum Season {
    WINTER,
    SPRING,
    SUMMER,
    AUTUMN;
}
