package Lesson1.Task5;

public class Main {
    public static void main(String[] args) {
        WeekDays sunday = WeekDays.SUNDAY;
        sunday.nameEn();
        sunday.nameUz();
        sunday.nameRu();
        WeekDays monday = WeekDays.MONDAY;
        monday.nameUz();
        monday.nameRu();
        monday.nameEn();

    }
}
