package Lesson1.Task5;

public interface UzRuEn {
    void nameRu();
    void nameUz();
    void  nameEn();
}
